// Background Service Worker - handles script injection and GM_* API proxying
const SCRIPT_CACHE = new Map();

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('[RoboMonkey] Extension installed');
  loadAllScripts();
});

// Listen for storage changes to reload scripts
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.scripts) {
    loadAllScripts();
  }
});

// Load scripts from storage into cache
async function loadAllScripts() {
  const data = await chrome.storage.local.get(['scripts']);
  const scripts = data.scripts || [];
  SCRIPT_CACHE.clear();
  scripts.filter(s => s.enabled).forEach(script => {
    script.matches.forEach(pattern => {
      if (!SCRIPT_CACHE.has(pattern)) SCRIPT_CACHE.set(pattern, []);
      SCRIPT_CACHE.get(pattern).push(script);
    });
  });
  console.log('[RoboMonkey] Loaded', scripts.length, 'scripts');
}

// Inject scripts when tab updates
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url || tab.url.startsWith('chrome://')) return;
  
  const scriptsToInject = [];
  for (const [pattern, scripts] of SCRIPT_CACHE) {
    if (matchPattern(tab.url, pattern)) {
      scriptsToInject.push(...scripts);
    }
  }
  
  if (scriptsToInject.length === 0) return;
  
  // Remove duplicates
  const unique = [...new Map(scriptsToInject.map(s => [s.id, s])).values()];
  
  for (const script of unique) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: injectUserScript,
        args: [script.id, script.code, script.grants || ['none']],
        world: 'MAIN'
      });
      console.log('[RoboMonkey] Injected', script.name, 'into', tab.url);
    } catch (e) {
      console.error('[RoboMonkey] Injection failed:', e);
    }
  }
});

// Function injected into page context
function injectUserScript(scriptId, code, grants) {
  // GM_* API emulation
  const GM = {};
  const storageKey = `gm_${scriptId}_`;
  
  GM.setValue = (key, value) => {
    return new Promise(resolve => {
      const fullKey = storageKey + key;
      localStorage.setItem(fullKey, JSON.stringify(value));
      resolve();
    });
  };
  
  GM.getValue = (key, defaultValue) => {
    return new Promise(resolve => {
      const fullKey = storageKey + key;
      const val = localStorage.getItem(fullKey);
      resolve(val ? JSON.parse(val) : defaultValue);
    });
  };
  
  GM.deleteValue = (key) => {
    return new Promise(resolve => {
      localStorage.removeItem(storageKey + key);
      resolve();
    });
  };
  
  GM.listValues = () => {
    return new Promise(resolve => {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(storageKey)) keys.push(k.replace(storageKey, ''));
      }
      resolve(keys);
    });
  };
  
  GM.addStyle = (css) => {
    const style = document.createElement('style');
    style.textContent = css;
    style.setAttribute('data-robo', scriptId);
    (document.head || document.documentElement).appendChild(style);
  };
  
  GM.xmlHttpRequest = (details) => {
    return new Promise((resolve, reject) => {
      fetch(details.url, {
        method: details.method || 'GET',
        headers: details.headers || {},
        body: details.data || null,
        credentials: details.withCredentials ? 'include' : 'same-origin'
      })
      .then(r => r.text())
      .then(text => {
        resolve({ responseText: text, status: 200, finalUrl: details.url });
      })
      .catch(reject);
    });
  };
  
  GM.log = (...args) => console.log(`[GM:${scriptId}]`, ...args);
  GM.info = { script: { name: scriptId, version: '1.0' }, scriptMetaStr: '' };
  
  // Build wrapper
  let wrapper = `(function() {\n`;
  wrapper += `const GM = ${JSON.stringify(Object.keys(GM))};\n`;
  wrapper += `const GM_setValue = ${GM.setValue.toString()};\n`;
  wrapper += `const GM_getValue = ${GM.getValue.toString()};\n`;
  wrapper += `const GM_deleteValue = ${GM.deleteValue.toString()};\n`;
  wrapper += `const GM_listValues = ${GM.listValues.toString()};\n`;
  wrapper += `const GM_addStyle = ${GM.addStyle.toString()};\n`;
  wrapper += `const GM_xmlHttpRequest = ${GM.xmlHttpRequest.toString()};\n`;
  wrapper += `const GM_log = ${GM.log.toString()};\n`;
  wrapper += `const GM_info = ${JSON.stringify(GM.info)};\n`;
  wrapper += `// Userscript code:\n`;
  wrapper += code;
  wrapper += `\n})();`;
  
  const script = document.createElement('script');
  script.textContent = wrapper;
  script.setAttribute('data-robo-monkey', scriptId);
  (document.body || document.documentElement).appendChild(script);
}

// Pattern matching for @match
function matchPattern(url, pattern) {
  const regex = pattern
    .replace(/\*\*/g, '<<<DOUBLESTAR>>>')
    .replace(/\*/g, '[^/]*')
    .replace(/<<<DOUBLESTAR>>>/g, '.*')
    .replace(/\?/g, '\\?');
  return new RegExp('^' + regex + '$').test(url);
}

// Message handling from sidepanel/popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'OPEN_SIDEPANEL') {
    chrome.sidePanel.open({ windowId: sender.tab?.windowId });
  }
  if (request.type === 'GET_SCRIPTS') {
    chrome.storage.local.get(['scripts']).then(data => {
      sendResponse(data.scripts || []);
    });
    return true;
  }
  if (request.type === 'SAVE_SCRIPTS') {
    chrome.storage.local.set({ scripts: request.scripts }).then(() => {
      loadAllScripts();
      sendResponse({ ok: true });
    });
    return true;
  }
  if (request.type === 'GET_VERSIONS') {
    chrome.storage.local.get(['versions']).then(data => {
      sendResponse(data.versions || {});
    });
    return true;
  }
  if (request.type === 'SAVE_VERSIONS') {
    chrome.storage.local.set({ versions: request.versions }).then(() => {
      sendResponse({ ok: true });
    });
    return true;
  }
  if (request.type === 'FETCH_OPENROUTER') {
    fetchOpenRouter(request.payload, request.apiKey).then(sendResponse).catch(e => {
      sendResponse({ error: e.message });
    });
    return true;
  }
  if (request.type === 'FETCH_GREASYFORK') {
    fetch(request.url).then(r => r.text()).then(sendResponse).catch(e => {
      sendResponse({ error: e.message });
    });
    return true;
  }
});

async function fetchOpenRouter(payload, apiKey) {
  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://robomonkey.local',
      'X-Title': 'RoboMonkey'
    },
    body: JSON.stringify(payload)
  });
  
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: { message: res.statusText } }));
    throw new Error(err.error?.message || `HTTP ${res.status}`);
  }
  
  return await res.json();
}

async function fetchModels(apiKey) {
  const res = await fetch('https://openrouter.ai/api/v1/models', {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://robomonkey.local',
      'X-Title': 'RoboMonkey'
    }
  });
  if (!res.ok) throw new Error('Failed to fetch models');
  return await res.json();
}

// Expose fetchModels for settings
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'FETCH_MODELS') {
    fetchModels(request.apiKey).then(sendResponse).catch(e => {
      sendResponse({ error: e.message });
    });
    return true;
  }
});