// Background Service Worker — script injection, API proxy, GM_* emulation
const SCRIPT_CACHE = new Map();

// ===== INIT =====
chrome.runtime.onInstalled.addListener(() => {
  console.log('[RoboMonkey] Extension installed');
  loadAllScripts();
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.scripts) loadAllScripts();
});

// ===== SCRIPT CACHE =====
async function loadAllScripts() {
  const data = await chrome.storage.local.get(['scripts']);
  const scripts = data.scripts || [];
  SCRIPT_CACHE.clear();
  scripts.filter(s => s.enabled).forEach(script => {
    (script.matches || []).forEach(pattern => {
      if (!SCRIPT_CACHE.has(pattern)) SCRIPT_CACHE.set(pattern, []);
      SCRIPT_CACHE.get(pattern).push(script);
    });
  });
  console.log('[RoboMonkey] Loaded', scripts.length, 'scripts');
}

// ===== INJECTION ON PAGE LOAD =====
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab?.url || tab.url.startsWith('chrome://')) return;
  await injectScriptsIntoTab(tabId, tab.url);
});

// ===== INJECT SCRIPTS INTO A SPECIFIC TAB =====
async function injectScriptsIntoTab(tabId, url) {
  const scriptsToInject = [];
  for (const [pattern, scripts] of SCRIPT_CACHE) {
    if (matchPattern(url, pattern)) scriptsToInject.push(...scripts);
  }
  if (scriptsToInject.length === 0) return;

  const unique = [...new Map(scriptsToInject.map(s => [s.id, s])).values()];

  for (const script of unique) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: runUserScript,
        args: [script.id, script.code, script.grants || ['none']],
        world: 'MAIN'
      });
      console.log('[RoboMonkey] Injected', script.name, 'into', url);
    } catch (e) {
      console.error('[RoboMonkey] Injection failed:', e);
    }
  }
}

// ===== DIRECT INJECTION (no cache needed) =====
async function injectScriptDirectly(tabId, scriptId, code, grants) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: runUserScript,
      args: [scriptId, code, grants],
      world: 'MAIN'
    });
    console.log('[RoboMonkey] Directly injected', scriptId);
  } catch (e) {
    console.error('[RoboMonkey] Direct injection failed:', e);
    throw e;
  }
}

// ===== INJECTED FUNCTION (runs in page context, MAIN world) =====
function runUserScript(scriptId, code, grants) {
  const storageKey = 'gm_' + scriptId + '_';

  const GM_setValue = function(key, value) {
    localStorage.setItem(storageKey + key, JSON.stringify(value));
  };

  const GM_getValue = function(key, defaultValue) {
    const v = localStorage.getItem(storageKey + key);
    return v ? JSON.parse(v) : defaultValue;
  };

  const GM_deleteValue = function(key) {
    localStorage.removeItem(storageKey + key);
  };

  const GM_listValues = function() {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(storageKey)) keys.push(k.slice(storageKey.length));
    }
    return keys;
  };

  const GM_addStyle = function(css) {
    const style = document.createElement('style');
    style.textContent = css;
    style.setAttribute('data-robo', scriptId);
    (document.head || document.documentElement).appendChild(style);
  };

  const GM_xmlHttpRequest = function(details) {
    return fetch(details.url, {
      method: details.method || 'GET',
      headers: details.headers || {},
      body: details.data || undefined,
      credentials: details.withCredentials ? 'include' : 'same-origin'
    })
    .then(function(r) {
      return r.text().then(function(text) {
        return {
          responseText: text,
          status: r.status,
          statusText: r.statusText,
          finalUrl: r.url,
          responseHeaders: Array.from(r.headers.entries()).map(function(e) { return e[0] + ': ' + e[1]; }).join('\n')
        };
      });
    });
  };

  const GM_log = function() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('[GM:' + scriptId + ']');
    console.log.apply(console, args);
  };

  const GM_info = {
    script: { name: scriptId, version: '1.0' },
    scriptMetaStr: '',
    version: '1.0',
    scriptWillUpdate: false
  };

  // Execute userscript with GM_* APIs available in scope
  try {
    const fn = new Function(
      'GM_setValue', 'GM_getValue', 'GM_deleteValue', 'GM_listValues',
      'GM_addStyle', 'GM_xmlHttpRequest', 'GM_log', 'GM_info',
      code
    );
    fn(GM_setValue, GM_getValue, GM_deleteValue, GM_listValues,
       GM_addStyle, GM_xmlHttpRequest, GM_log, GM_info);
  } catch (err) {
    console.error('[RoboMonkey:' + scriptId + ']', err);
  }
}

// ===== PATTERN MATCHING (Tampermonkey-style @match) =====
function matchPattern(url, pattern) {
  try {
    const pParts = pattern.split('/');
    const schemePat = pParts[0];
    const hostPat = pParts[2];
    const pathPat = pParts.slice(3).join('/');
    const u = new URL(url);

    if (schemePat !== '*') {
      const schemes = schemePat.split('|');
      if (!schemes.includes(u.protocol.slice(0, -1))) return false;
    }

    if (hostPat !== '*') {
      const hostRe = '^' + hostPat
        .replace(/\*\./g, '([^/.]+\\.)*')
        .replace(/\.\*/g, '(\\.[^/]+)*')
        .replace(/\*/g, '[^/.]*') + '$';
      if (!new RegExp(hostRe).test(u.hostname)) return false;
    }

    const pathRe = '^' + pathPat
      .replace(/\*\*/g, '<<<DOUBLE>>>')
      .replace(/\*/g, '[^/]*')
      .replace(/<<<DOUBLE>>>/g, '.*') + '$';
    if (!new RegExp(pathRe).test(u.pathname)) return true;

    return true;
  } catch (e) {
    const regex = pattern
      .replace(/\*\*/g, '<<<DS>>>')
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/<<<DS>>>/g, '.*')
      .replace(/\\\*/g, '[^/]*');
    return new RegExp('^' + regex + '$').test(url);
  }
}

// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { type } = request;

  if (type === 'GET_SCRIPTS') {
    chrome.storage.local.get(['scripts']).then(d => sendResponse(d.scripts || []));
    return true;
  }

  if (type === 'SAVE_SCRIPTS') {
    chrome.storage.local.set({ scripts: request.scripts }).then(() => {
      loadAllScripts();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (type === 'INJECT_NOW') {
    // If script provided, inject directly (bypass cache — for immediate post-creation injection)
    if (request.script) {
      const s = request.script;
      injectScriptDirectly(request.tabId, s.id, s.code, s.grants || ['none'])
        .then(() => sendResponse({ ok: true }))
        .catch(e => sendResponse({ error: e.message }));
    } else {
      injectScriptsIntoTab(request.tabId, request.url)
        .then(() => sendResponse({ ok: true }))
        .catch(e => sendResponse({ error: e.message }));
    }
    return true;
  }

  if (type === 'FETCH_OPENROUTER') {
    fetchOpenRouter(request.payload, request.apiKey)
      .then(sendResponse)
      .catch(e => sendResponse({ error: e.message }));
    return true;
  }

  if (type === 'FETCH_GREASYFORK') {
    fetch(request.url).then(r => r.text()).then(sendResponse)
      .catch(e => sendResponse({ error: e.message }));
    return true;
  }

  if (type === 'FETCH_MODELS') {
    fetchModels(request.apiKey)
      .then(sendResponse)
      .catch(e => sendResponse({ error: e.message }));
    return true;
  }

  return false;
});

// ===== API HELPERS =====
async function fetchOpenRouter(payload, apiKey) {
  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://robomonkey.local',
      'X-Title': 'RoboMonkey'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: { message: res.statusText } }));
    throw new Error(err.error?.message || `HTTP ${res.status}`);
  }
  return await res.json();
}

async function fetchModels(apiKey) {
  const res = await fetch('https://openrouter.ai/api/v1/models', {
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://robomonkey.local',
      'X-Title': 'RoboMonkey'
    }
  });
  if (!res.ok) throw new Error('Failed to fetch models');
  return await res.json();
}
